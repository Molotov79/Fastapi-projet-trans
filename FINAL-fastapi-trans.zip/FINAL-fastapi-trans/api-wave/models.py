from sqlalchemy import Column, Integer, String
from database import Base


class Envoi(Base):
    __tablename__ = "envoi"

    id_envoi = Column(Integer, primary_key=True)
    nom_user = Column(String)
    numero_user = Column(String)
    nom_destinataire = Column(String)
    numero_destinataire = Column(String)
    Montant = Column(String)
    date_time = Column(String)



class Depot(Base):
    __tablename__= "depot"

    id_depot = Column(Integer, primary_key=True)
    nom_destinataire_depot = Column(String)
    numero_destinataire_depot = Column(String)
    depot_montant = Column(String)
    depot_date_time = Column(String)


class Retrait(Base):
    __tablename__="retrait"

    id_retrait=Column(Integer, primary_key=True)
    numero_user_retrait=Column(String)
    retrait_montant=Column(String)
    retrait_date_time = Column(String)




class Facture(Base):
    __tablename__="facture"

    id_facture= Column(Integer, primary_key=True)
    numero_payeur = Column(String)
    facture_montant = Column(String)
    facture_date_time = Column(String)





