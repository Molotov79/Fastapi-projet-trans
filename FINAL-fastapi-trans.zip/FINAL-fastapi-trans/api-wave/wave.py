from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, Field
import models
from database import engine, SessionLocal
from sqlalchemy.orm import Session

app = FastAPI()

models.Base.metadata.create_all(bind=engine)

def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()


'''---------------------------------------ENVOIS--------------------------------------------------------------------------------------------------------------'''



class Envoi(BaseModel):
    nom_user : str = Field(min_length=1)
    numero_user : str = Field(min_length=1, max_length=100)
    nom_destinataire : str = Field(min_length=1, max_length=100)
    numero_destinataire: str = Field(min_length=1, max_length=100)
    montant : str = Field(min_length=1, max_length=100)
    date_time : str = Field(min_length=1, max_length=100)




@app.get("/")
def Home():
    return {"Bienvenue dans l'accueil dans l'API de WAVE  "}


@app.get("/get-envois",tags=['envoi'])
def get_envois(db: Session = Depends(get_db)):
    return db.query(models.Envoi).all()


@app.post("/post",tags=['envoi'])
def create_envoi(envoi: Envoi, db: Session = Depends(get_db)):

    envoi_model = models.Envoi()
    envoi_model.nom_user = envoi.nom_user
    envoi_model.numero_user = envoi.numero_user
    envoi_model.nom_destinataire = envoi.nom_destinataire
    envoi_model.numero_destinataire = envoi.numero_destinataire
    envoi_model.montant=envoi.montant
    envoi_model.date_time=envoi.date_time

    db.add(envoi_model)
    db.commit()

    return envoi


@app.put("/update_envoi/{envoi_id}",tags=['envoi'])
def update_envoi(envoi_id: int, envoi: Envoi, db: Session = Depends(get_db)):

    envoi_model = db.query(models.Envoi).filter(models.Envoi.id_envoi == envoi_id).first()

    if envoi_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {envoi_id} : Does not exist"
        )

    envoi_model.nom_user = envoi.nom_user
    envoi_model.numero_user = envoi.numero_user
    envoi_model.nom_destinataire = envoi.nom_destinataire
    envoi_model.numero_destinataire = envoi.numero_destinataire
    envoi_model.montant = envoi.montant

    db.add(envoi_model)
    db.commit()

    return envoi


@app.delete("/delete_envoi/{envoi_id}",tags=['envoi'])
def delete_envoi(envoi_id: int, db: Session = Depends(get_db)):

    envoi_model = db.query(models.Envoi).filter(models.Envoi.id_envoi == envoi_id).first()

    if envoi_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {envoi_id} : Does not exist"
        )

    db.query(models.Envoi).filter(models.Envoi.id_envoi == envoi_id).delete()

    db.commit()
    return {"Deleted successfully"}


'''----------------------Depot----------------------------------------------------------------------'''




class Depot(BaseModel):
    nom_destinataire_depot: str = Field(min_length=1, max_length=100)
    numero_destinataire_depot: str = Field(min_length=1, max_length=100)
    depot_montant:  str = Field(min_length=1, max_length=100)
    depot_date_time: str = Field(min_length=1, max_length=100)



@app.get("/get_depots",tags=['depot'])
def get_depot(db: Session = Depends(get_db)):
    return db.query(models.Depot).all()


@app.post("/create_depot/{id_depot}",tags=['depot'])
def create_depot(depot: Depot, db: Session = Depends(get_db)):

    depot_model = models.Depot()
    depot_model.nom_destinataire_depot= depot.nom_destinataire_depot
    depot_model.numero_destinataire_depot= depot.numero_destinataire_depot
    depot_model.depot_montant= depot.depot_montant
    depot_model.depot_date_time= depot.depot_date_time

    db.add(depot_model)
    db.commit()

    return depot


@app.put("/update_depot/{envoi_id}",tags=['depot'])
def update_depot(depot_id: int, depot: Depot, db: Session = Depends(get_db)):

    depot_model = db.query(models.Depot).filter(models.Depot.depot_id == depot_id).first()

    if depot_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {depot_id} : Does not exist"
        )


    depot_model.nom_destinataire_depot = depot.nom_destinataire_depot
    depot_model.numero_destinataire_depot= depot.numero_destinataire_depot
    depot_model.depot_montant = depot.depot_montant
    depot_model.depot_date_time=depot.depot_date_time

    db.add(depot_model)
    db.commit()

    return depot


@app.delete("/delete_depot/{depot_id}",tags=['depot'])
def delete_depot(depot_id: int, db: Session = Depends(get_db)):

    depot_model = db.query(models.Depot).filter(models.Depot.depot_id == depot_id).first()

    if depot_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {depot_id} : Does not exist"
        )

    db.query(models.Depot).filter(models.Depot.depot_id == depot_id).delete()

    db.commit()
    return {"Deleted successfully"}



'''--------------------------------------RETRAITS--------------------------------------------------------------------------------------------------------------'''



class Retrait(BaseModel):
    numero_user_retait: str = Field(min_length=1, max_length=100)
    retrait_montant : str = Field(min_length=1, max_length=100)
    retrait_date_time : str = Field(min_length=1, max_length=100)



@app.get("/get_retraits",tags=['retrait'])
def get_retrait(db: Session = Depends(get_db)):
    return db.query(models.Retrait).all()


@app.post("/create_retrait/{id_retrait}",tags=['retrait'])
def create_retrait(retrait: Retrait, db: Session = Depends(get_db)):

    retrait_model = models.Retrait()

    retrait_model.numero_user_retrait= retrait.numero_user_retait
    retrait_model.retrait_montant= retrait.retrait_montant
    retrait_model.retrait_date_time=retrait.retrait_date_time

    db.add(retrait_model)
    db.commit()

    return retrait


@app.put("/update_retrait/{id_retrait}",tags=['retrait'])
def update_retrait(id_retrait: int, retrait: Retrait, db: Session = Depends(get_db)):

    retrait_model = db.query(models.Retrait).filter(models.Retrait.id_retrait ==id_retrait).first()

    if retrait_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {id_retrait} : Does not exist"
        )

    retrait_model.numero_user_retrait = retrait.numero_user_retait
    retrait_model.retrait_montant = retrait.retrait_montant
    retrait_model.retrait_date_time = retrait.retrait_date_time

    db.add(retrait_model)
    db.commit()

    return retrait


@app.delete("/delete_retrait/{id_retrait}",tags=['retrait'])
def delete_retrait(id_retrait : int, db: Session = Depends(get_db)):

    retrait_model = db.query(models.Retrait).filter(models.Retrait.id_retrait ==id_retrait).first()

    if retrait_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {id_retrait} : Does not exist"
        )

    db.query(models.Retrait).filter(models.Retrait.id_retrait == id_retrait).delete()

    db.commit()
    return {"Deleted successfully"}



'''---------------------------------------FACTURE------------------------------------'''


class Facture(BaseModel):
    numero_payeur: str = Field(min_length=1, max_length=100)
    facture_montant : str = Field(min_length=1, max_length=100)
    facture_date_time : str = Field(min_length=1, max_length=100)



@app.get("/get_facture",tags=['facture'])
def get_facture(db: Session = Depends(get_db)):
    return db.query(models.Facture).all()


@app.post("/create_facture/{id_facture}",tags=['facture'])
def create_facture(facture: Facture, db: Session = Depends(get_db)):

    facture_model = models.Facture()

    facture_model.numero_payeur= facture.numero_payeur
    facture_model.facture_montant= facture.facture_montant
    facture_model.facture_date_time=facture.facture_date_time

    db.add(facture_model)
    db.commit()

    return facture


@app.put("/update_facture/{id_facture}",tags=['facture'])
def update_facture(id_facture: int, facture: Facture, db: Session = Depends(get_db)):

    facture_model = db.query(models.Facture).filter(models.Facture.id_facture ==id_facture).first()

    if facture_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {id_facture} : Does not exist"
        )

    facture_model.numero_payeur = facture.numero_payeur
    facture_model.facture_montant = facture.facture_montant
    facture_model.facture_date_time = facture.facture_date_time

    db.add(facture_model)
    db.commit()

    return facture


@app.delete("/delete_facture/{id_facture}",tags=['facture'])
def delete_facture(id_facture : int, db: Session = Depends(get_db)):

    facture_model = db.query(models.Facture).filter(models.Facture.id_facture ==id_facture).first()

    if facture_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {id_facture} : Does not exist"
        )

    db.query(models.Facture).filter(models.Facture.id_facture == id_facture).delete()

    db.commit()
    return {"Deleted successfully"}

